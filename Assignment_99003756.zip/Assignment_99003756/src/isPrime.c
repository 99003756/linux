#include "myutils.h"

int isPrime(int a)
{
    int c;
    for(c = 2;c <= (a-1);c++)
    {
        if(a%c == 0)
        return 0;
    }
    return 1;
}