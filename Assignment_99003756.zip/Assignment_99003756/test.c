#include "mystring.h"
#include "myutils.h"
#include "bitmask.h"

int main()
{
    char s1[20] = "check-string";
    char s2[20];
    char s3[20] = "Check string";
    int n = 5;
    int k=1;
    int m = 121;
    int o;
    int a = 5;
    printf("String length = %d\n",mystrlen(s1));
    printf("Copy: String s1 = %s String s2 = %s\n",s1,mystrcpy(s1,s2));
    printf("Cat: String s1 = %s String s2 = %s\n",s2,mystrcat(s1,s2));
    printf("compare: 0->Equal 1->Not equal\n");
    printf("Checking... %d\n",mystrcmp(s1,s3));
    printf("Factorial of %d = %d\n",n,factorial(n));
    printf("Checking prime : 0->Not prime 1->Prime\n");
    printf("%d\n",isPrime(n));
    printf("Checking palindrome 0->palindrome 1-> Not palindrome\n");
    printf("%d\n",ispalindrome(m));
    printf("Vsum of 2 numbers = %lf\n",vsum(2,10,20));
    printf("Set %d = %d\n",a,set(a,k));
    printf("Reset %d = %d\n",a,reset(a,k));
    printf("Flip of %d = %d",a,flip(a,o));
}
