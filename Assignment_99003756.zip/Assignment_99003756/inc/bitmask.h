#ifndef __BITMASK_H
#define __BITMASK_H

int set(int n,int k);

int reset(int n,int k);

int flip(int n,int o);

#endif